/*************************************************************************
  > File Name: test_rootserver.cpp
  > Author: cooperz
  > Mail: zbzcsn@qq.com
  > Created Time: Sat 01 Aug 2015 08:52:50 AM UTC
 ************************************************************************/
//#include "IOServicePool.h"
//
#include<iostream>
#include "RootSession.h"
#include "DBManager.h"
#include "IOServicePool.h"
#include "SessionManager.h"
#include "../../common/includeopencv/interface.h"
#include "NodeUtil.h"


using namespace std;
using namespace NodeServer;

Matcher* g_pic_matcher;
DBManager* g_db_manager;
IOServicePool* g_io_service_pool;
SessionManager* g_session_manager; 

int main(int argn, char** argv)
{
    if(argn !=1)
    {
        cout<< "do not need parm " <<argv[1]<<endl;
    }

	g_pic_matcher = new Matcher();
    if((access (INDEXPATH,F_OK)) == 0)
    {
        g_pic_matcher->loadIndex(INDEXPATH);
    }
    else
    {
        g_pic_matcher->train(TRANDIR, FEATUREPATH, INDEXPATH);
    }
    g_db_manager = new DBManager();
    g_db_manager->init();
	
	g_io_service_pool = new IOServicePool(1);//������̳߳صĴ�С
	g_io_service_pool->start();
	g_io_service_pool->join();
	g_session_manager = new SessionManager();
    RootSession s(6002);
    s.Run();
    while(true)
    {
        sleep(1000);
    }
    return 0;
}
