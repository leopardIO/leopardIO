/*************************************************************************
	> File Name: test.cpp
	> Author: zhonghx
	> Mail: zhonghongxia@foxmail.com
	> Created Time: Thu 06 Aug 2015 07:57:38 AM UTC
 ************************************************************************/

#include<iostream>
#include "a.h"
using namespace std;

