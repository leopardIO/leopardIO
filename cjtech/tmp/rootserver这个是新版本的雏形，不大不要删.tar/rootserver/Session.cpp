﻿#include "Session.h"
Session ::Session()
    :bIsRecycler_(false)
{
    
}
